var params = window.location.search.replace('?','').split('&').reduce(function(p,e){
            var a = e.split('=');
            p[ decodeURIComponent(a[0])] = decodeURIComponent(a[1]);
            return p;
        });
	var site;
	if(params == "shirt"){
		$("#navbar").addClass("bg-orange");
		$("#navbar-brand").text("Одежда");
		site = "shirt-category.html?shirt";
	} else if(params == "shoe"){
		$("#navbar").addClass("bg-blue");
		$("#navbar-brand").text("Обувь");
		site = "shoe-category.html?shoe";
	} else if(params == "cosmetics"){
		$("#navbar").addClass("bg-pink");
		$("#navbar-brand").text("Красота");
		site = "cosmetics-category.html?cosmetics";
	} else if(params == "food"){
		$("#navbar").addClass("bg-yellow");
		$("#navbar-brand").text("Еда");
		site = "food-category.html?food";
	} else if(params == "techincs"){
		$("#navbar").addClass("bg-grey");
		$("#navbar-brand").text("Техника");
		site = "technics-category.html?techincs";
	}
	$(document).ready(function(){
		var blocks = document.querySelectorAll(".discount");
		$.ajax({
	          url: 'http://balanceeeplus.com/categorydirect',
	          data: {
	          	"category" : params
	          },
	          error: function(xhr, status, error) {
                alert(xhr.status+status+error);
              },
	          success: function(data) {
		        if(data.length>0){
		          	for (var i = 0; i < data.length; i++) {
		          		data[i].time = "до "+data[i].time;
		          		data[i].fileurl = "http://balanceeeplus.com/uploads/"+data[i].fileurl;
		          		data[i].html = site;
		          		data[i].id = box.length+i;
		          		box[box.length + i] = data[i];
		          	}
		            for (var i = 0; i < data.length; i++) {
		            	for(var a=0;a<blocks.length;a++){	            		
							blocks[a].innerHTML+=`<div class='bg-white w-100 p-1 mb-2' style='border-radius:0.5rem'><div class='row no-gutters'><div class='col-4 img-floor'><div class='border-img'><div class='disc-img' style='background-image: url("`+data[i].fileurl+`")'></div></div></div><div class='col-8 p-1'><h5 class='text-justifer w-100 cardtheme rednormal-text organize-des'>`+data[i].title+`</h5><p class='organize'>`+data[i].description+`</p></div><div class='col-12 px-2'><div class='d-inline-block' style='width:1rem;'><img src='images/clock.png' style='width:1rem;' alt='date:'></div><p class='d-inline ml-1 cardtheme'>`+data[i].time+`</p><h6 class='mb-0'>Магазин: <span class='text-muted'>`+data[i].name+`</span></h6><h6>Адрес: <span class='text-muted'>`+data[i].address+`</span></h6></div><a href='more-discount.html?' id='detail' num='`+data[i].id+`'><button type='button' class='btn btn-info'>Подробнее</button></a><div class='col-6 px-2'></div></div></div>`;
						}
		            }
	          	}
				var buttons = document.querySelectorAll("#detail");
				for(var i=0;i<buttons.length;i++){
					buttons[i].onclick = function(){
						sessionStorage.setItem('maindiscount',  JSON.stringify(box[this.getAttribute("num")]));
					}
				}
	          }
	    });
	});
/*
<div class='bg-white w-100 p-1 mb-2' style='border-radius:0.5rem'>
	<div class='row no-gutters'><div class='col-4 img-floor'>
			<div class='border-img'>
				<div class='disc-img' style='background-image: url(`http://balanceeeplus.com/uploads/"+data[i].fileurl+"`)'></div>
			</div>
		</div>
		<div class='col-8 p-1'>
			<h5 class='text-justifer w-100 cardtheme rednormal-text organize-des'>"+data[i].title+"</h5><p class='organize'>"+data[i].description+"</p>
		</div>
		<div class='col-12 px-2'>
		<div class='d-inline-block' style='width:1rem;'>
			<img src='images/clock.png' style='width:1rem;' alt='date:'>
		</div>
			<p class='d-inline ml-1 cardtheme'>"+data[i].time+"</p>
			<h6 class='mb-0'>Магазин: <span class='text-muted'>"+data[i].name+"</span></h6>
			<h6>Адрес: <span class='text-muted'>"+data[i].address+"</span></h6>
		</div>
		<a href='more-discount.html?' id='detail' num='0'><button type='button' class='btn btn-info'>Подробнее</button></a>
		<div class='col-6 px-2'>
			
		</div>
	</div></div>
<div class="bg-white w-100 p-1 mb-4" style="border-radius:0.5rem">
	<div class="row no-gutters"><div class="col-4 img-floor">
			<div class="border-img">
				<div class="disc-img" style="background-image: url('images/22.jpeg')"></div>
			</div>
		</div>
		<div class="col-8 p-2">
			<h1 class="text-justifer w-100 cardtheme rednormal-text" style="font-size:3rem">Lamoda «Распродажа стильных рюкзаков в интернет-магазине Ламода»</h1><h1 class="organize">Скидка 30% предоставляется на весь ассортимент Зимней верхней одежды из Новой коллекции в магазинах ACOOLA, в том числе товары других марок: ACOOLA baby, LUHTA, кроме товаров со скидкой.</h1>
		</div>
		<div class="col-12 px-2">
		<div class="d-inline-block" style="width:2rem;">
			<img src="images/clock.png" style="width:2rem;" alt="date:">
		</div>
			<h2 class="d-inline ml-1 cardtheme">до 2018-10-14</h2>
			<h2 class="mb-0">Магазин: <span class="text-muted">Acoola</span></h2>
			<h2>Адрес: <span class="text-muted">ул. Федора Попова, 17</span></h2>
		</div>
		<div class="col-6 px-2">
			
		</div>
	</div></div>
*/